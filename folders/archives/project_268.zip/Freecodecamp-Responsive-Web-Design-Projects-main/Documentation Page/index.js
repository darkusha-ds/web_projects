function myFunction0() {
    var copyText = document.getElementById("select-this0");
    copyText.select();
    copyText.setSelectionRange(0, 99999)
    document.execCommand("copy");
}

function myFunction() {
    var copyText = document.getElementById("select-this2");
    copyText.select();
    copyText.setSelectionRange(0, 99999)
    document.execCommand("copy");
}

function myFunction4() {
    var copyText = document.getElementById("select-this4");
    copyText.select();
    copyText.setSelectionRange(0, 99999)
    document.execCommand("copy");
}

function myFunction5() {
    var copyText = document.getElementById("select-this5");
    copyText.select();
    copyText.setSelectionRange(0, 99999)
    document.execCommand("copy");
}
