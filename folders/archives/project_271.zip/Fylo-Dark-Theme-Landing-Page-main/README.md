# Frontend Mentor - Fylo landing page with dark theme and features grid

![Design preview for the Fylo landing page with dark theme and features grid challenge](./design/desktop-preview.jpg)

## Welcome! 👋

Thanks you for checking out my solution for this front-end coding challenge.

[Frontend Mentor](https://www.frontendmentor.io) challenges allow you to improve your skills in a real-life workflow.

**To do this challenge you need a basic understanding of HTML and CSS.**

## Where to find everything

Your task is to build out the project to the designs inside the `/design` folder. You will find both a mobile and a desktop version of the design to work to.

The designs are in JPG static format. This will mean that you'll need to use your best judgment for styles such as `font-size`, `padding` and `margin`. This should help train your eye to perceive differences in spacings and sizes.

If you would like the Sketch file in order to see sizes etc, it is available to download from the challenge page.

You will find all the required assets in the `/images` folder. The assets are already optimized.

There is also a `style-guide.md` file, which contains the information you'll need, such as color palette and fonts.

## Deployed Solution

[![Netlify Status](https://api.netlify.com/api/v1/badges/6ad40414-dafe-4278-8e14-3e7829da9978/deploy-status)](https://app.netlify.com/sites/laughing-easley-23c276/deploys)

Preview Here: https://laughing-easley-23c276.netlify.app/

**Have fun building!** 🚀
