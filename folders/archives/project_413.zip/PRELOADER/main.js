const loaderContainer = document.querySelector('.loader-container');

window.addEventListener('load',()=>{
    loaderContainer.classList.add('hide');
})