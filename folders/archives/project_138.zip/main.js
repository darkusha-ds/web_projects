$('.ticket').click(function () {
    $('.ticket-in').toggleClass('active');
});