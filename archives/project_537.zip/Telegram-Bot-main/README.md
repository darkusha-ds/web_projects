# Simple Telegram Bot Using Python 
This bot will reply with what ever you send.

First get API Token from<a href="https://telegram.me/BotFather"> Bot Father</a> <br>
Install Python Package to handle telegram bot by running - `pip install python-telegram-bot` <br>
Follow <a href="https://www.instagram.com/tarun_code.py/"> Tarun KS</a>
